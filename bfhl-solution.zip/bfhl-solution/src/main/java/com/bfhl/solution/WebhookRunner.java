package com.bfhl.solution;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class WebhookRunner implements ApplicationRunner {

    // ================================================================
    //  🔴 CHANGE THESE 3 VALUES TO YOUR ACTUAL DETAILS BEFORE RUNNING
    // ================================================================
    private static final String NAME   = "John Doe";
    private static final String REG_NO = "REG12347";
    private static final String EMAIL  = "john@example.com";
    // ================================================================

    private static final String GENERATE_URL = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

    // ================================================================
    //  🔴 PASTE YOUR SQL QUERY HERE AFTER READING YOUR QUESTION PDF
    //     This is just a placeholder — replace with the real answer
    // ================================================================
    private static final String SQL_QUERY =
            "SELECT e.EmpID, e.FirstName, e.LastName, d.DepartmentName, e.Salary "
          + "FROM Employees e "
          + "JOIN Departments d ON e.DeptID = d.DeptID "
          + "WHERE e.Salary > (SELECT AVG(e2.Salary) FROM Employees e2 WHERE e2.DeptID = e.DeptID) "
          + "ORDER BY e.Salary DESC";
    // ================================================================

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public void run(ApplicationArguments args) {
        System.out.println("\n╔══════════════════════════════════════════╗");
        System.out.println("║   BFHL Qualifier 1 — Java Solution       ║");
        System.out.println("╚══════════════════════════════════════════╝\n");

        // ---------- STEP 1: Call generateWebhook ----------
        System.out.println("[STEP 1] Sending POST to generateWebhook...");
        System.out.println("         Name  : " + NAME);
        System.out.println("         RegNo : " + REG_NO);
        System.out.println("         Email : " + EMAIL);

        // Determine question number
        String digits = REG_NO.replaceAll("[^0-9]", "");
        int lastTwo = Integer.parseInt(digits.substring(Math.max(0, digits.length() - 2)));
        String questionType = (lastTwo % 2 != 0) ? "Question 1 (ODD)" : "Question 2 (EVEN)";
        System.out.println("         Last 2 digits: " + lastTwo + " → " + questionType);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, String> body = Map.of(
                "name",  NAME,
                "regNo", REG_NO,
                "email", EMAIL
        );

        HttpEntity<Map<String, String>> request = new HttpEntity<>(body, headers);

        WebhookResponse webhookResp;
        try {
            ResponseEntity<WebhookResponse> response = restTemplate.exchange(
                    GENERATE_URL, HttpMethod.POST, request, WebhookResponse.class
            );
            webhookResp = response.getBody();
        } catch (Exception e) {
            System.out.println("\n[ERROR] generateWebhook call failed: " + e.getMessage());
            e.printStackTrace();
            return;
        }

        if (webhookResp == null || webhookResp.webhook == null || webhookResp.accessToken == null) {
            System.out.println("[ERROR] Response is missing webhook or accessToken!");
            System.out.println("        Full response: " + webhookResp);
            return;
        }

        System.out.println("\n[STEP 1 ✅] Received:");
        System.out.println("         Webhook URL  : " + webhookResp.webhook);
        System.out.println("         Access Token : " + webhookResp.accessToken.substring(0, 30) + "...");

        // ---------- STEP 2: Submit SQL query ----------
        System.out.println("\n[STEP 2] Submitting SQL query to webhook...");
        System.out.println("         Query: " + SQL_QUERY.substring(0, Math.min(80, SQL_QUERY.length())) + "...");

        HttpHeaders submitHeaders = new HttpHeaders();
        submitHeaders.setContentType(MediaType.APPLICATION_JSON);
        submitHeaders.set("Authorization", webhookResp.accessToken);

        Map<String, String> submitBody = Map.of("finalQuery", SQL_QUERY);
        HttpEntity<Map<String, String>> submitRequest = new HttpEntity<>(submitBody, submitHeaders);

        // Retry up to 4 times
        for (int attempt = 1; attempt <= 4; attempt++) {
            try {
                System.out.println("         Attempt " + attempt + "...");
                ResponseEntity<String> submitResponse = restTemplate.exchange(
                        webhookResp.webhook, HttpMethod.POST, submitRequest, String.class
                );
                System.out.println("\n[STEP 2 ✅] Submission successful!");
                System.out.println("         Status : " + submitResponse.getStatusCode());
                System.out.println("         Body   : " + submitResponse.getBody());
                System.out.println("\n╔══════════════════════════════════════════╗");
                System.out.println("║   ✅ DONE! Solution submitted!           ║");
                System.out.println("╚══════════════════════════════════════════╝\n");
                return;

            } catch (HttpClientErrorException e) {
                System.out.println("         ❌ HTTP " + e.getStatusCode() + ": " + e.getResponseBodyAsString());
                if (attempt < 4) {
                    System.out.println("         Retrying in 2 seconds...");
                    sleep(2000);
                }
            } catch (Exception e) {
                System.out.println("         ❌ Error: " + e.getMessage());
                if (attempt < 4) {
                    System.out.println("         Retrying in 2 seconds...");
                    sleep(2000);
                }
            }
        }

        System.out.println("\n[ERROR] All attempts failed. Check your token / URL / query.");
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    // ---------- Response model ----------
    @JsonIgnoreProperties(ignoreUnknown = true)
    static class WebhookResponse {
        @JsonProperty("webhook")
        public String webhook;

        @JsonProperty("accessToken")
        public String accessToken;

        @Override
        public String toString() {
            return "WebhookResponse{webhook='" + webhook + "', accessToken='" +
                   (accessToken != null ? accessToken.substring(0, 20) + "..." : "null") + "'}";
        }
    }
}
