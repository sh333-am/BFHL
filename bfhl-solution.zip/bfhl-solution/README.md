# BFHL Qualifier 1 — Java Solution

## How to Use

### 1. Open in IntelliJ
- File → Open → select the `bfhl-solution` folder
- IntelliJ will auto-detect the Maven project and download dependencies

### 2. Update Your Details
Open `src/main/java/com/bfhl/solution/WebhookRunner.java` and change:

```java
private static final String NAME   = "Your Name";
private static final String REG_NO = "YOUR_REG_NO";
private static final String EMAIL  = "your@email.com";
```

### 3. Update the SQL Query
After reading your assigned question PDF, update:

```java
private static final String SQL_QUERY = "YOUR SQL QUERY HERE";
```

### 4. Run
- Right-click `BfhlApplication.java` → Run
- OR via terminal: `mvn spring-boot:run`

### 5. Build JAR
```bash
mvn clean package -DskipTests
```
JAR will be at: `target/bfhl-solution.jar`

Run JAR: `java -jar target/bfhl-solution.jar`

## Project Structure
```
src/main/java/com/bfhl/solution/
├── BfhlApplication.java   — Spring Boot entry point
├── AppConfig.java          — RestTemplate bean
└── WebhookRunner.java      — Main logic (runs on startup)
```
